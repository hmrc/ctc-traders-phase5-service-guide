#! /usr/bin/python3

import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder

# Add your bearer token here, without the "Bearer " prefix
bearer_token = "<>"

# The filename, relative from the working directory, sample included
# (though make sure you update the LRN in the sample)
file_name = "file.xml"

# The departure declaration URL on Sandbox
declaration_url = "https://test-api.service.hmrc.gov.uk/customs/transits/movements/departures"

# Make a request with a blank payload
request_result = requests.post(
    url=declaration_url,
    headers={
        "Authorization": f"Bearer {bearer_token}",
        "Accept": "application/vnd.hmrc.2.0+json"
    }
)

if request_result.status_code > 399:
    print(f"An error occurred while trying to initiate a file upload, status code {request_result.status_code}")
    print(request_result.text)
else:
    """
    Once this request has been made, we'll get back a Json document that contains
    an "uploadRequest" object. In there will be two fields, href and fields.
    
    We will upload the message to the URL provided at "href". We need to do this 
    as multipart form encoded data, and we need to include the data in the fields
    json message. The various entries in the fields document need to come first,
    followed by the message in a part named "file". You should also include the 
    content type as application/xml.
    """

    initial_result = request_result.json()

    # Retrieves the departure and PPNS box ID (if any) for display.
    departure_id = str(initial_result['_links']['self']['href']).rsplit('/', 1)[1]
    print(f"Departure ID: {departure_id}")

    box_id = initial_result.get('boxId', 'none')
    print(f"Box ID: {box_id}")

    # The upload URL and the fields to add to the second request
    upload_url = str(initial_result['uploadRequest']['href'])
    fields = initial_result['uploadRequest']['fields']

    print(f"Sending request to {upload_url}")

    # The contents of the file are added to the fields -- Python 3.6+ maintains insertion order
    # so in this case the file field is at the end.
    #
    # The fields need to be in a multipart encoding
    fields['file'] = ('file.xml', open("file.xml", "rb"), 'application/xml')
    mp_fields = MultipartEncoder(
        fields=fields
    )

    # Posts the file and metadata to the provided URL
    upscan_result = requests.post(
        url=upload_url,
        data=mp_fields,
        headers={'Content-Type': mp_fields.content_type}
    )

    print(f"Request sent to {upload_url}")

    # We currently expect a 204, but you can expect any 2xx HTTP code.
    print(upscan_result.status_code)

    if upscan_result.status_code != 204:
        print(f"Error was: {upscan_result.text}")