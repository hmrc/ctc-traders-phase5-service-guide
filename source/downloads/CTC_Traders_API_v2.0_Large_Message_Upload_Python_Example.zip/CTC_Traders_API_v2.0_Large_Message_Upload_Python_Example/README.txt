This is an example Python script that demonstrates how to upload a file by the CTC Traders API large message route. It was written using Python 3.9 and the packages listed in requirements.txt.

If you want to use the script, complete the following steps:
1. Create a virtual environment.
2. Install the requirements using "pip -r requirements.txt".
3. Generate a user-restricted access token with the "common-transit-convention-traders" scope that can access CTC Traders API v2.0.
4. Add the generated token to the "bearer_token" variable in the script.
5. Execute the script.

You can use your own declarations if you prefer - simply change the "file_name" variable to point to your file.